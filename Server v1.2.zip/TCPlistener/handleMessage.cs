﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCPlistener
{
    class handleMessage
    {
        public string Message { get; set; }

        public handleMessage(string message)
        {
            Message = message;
        }

        public string Compare(string bericht)
        {
            if (bericht.Equals("%Hello$"))
            {
                ACK(bericht);
            }
            else if (bericht.Equals("%Lijst ophalen$"))
            {
                List<RFID> list = new List<RFID>();
               list = RFID.LoadAllFromDatabase();
                string message = "";
                foreach (RFID rfid in list)
                {
                    message += Convert.ToString(rfid.Nummer) + ":" + Convert.ToString(rfid.Snelheid) + ",";
                }
                Message = message;
            }
            else if (bericht.StartsWith("%Voeg RFID Toe"))
            {
                string[] woorden = bericht.Split(':');
                if (woorden[0] == "%Voeg RFID Toe")
                {
                    string[] insert = woorden[1].Split(',');
                    string snelheid = insert[1].TrimEnd('$');
                    RFID rfid = new RFID(Convert.ToInt32(insert[0]),Convert.ToInt32(snelheid));
                    RFID.SaveToDatabase(rfid.Nummer, rfid.Snelheid);
                    Message = "RFID toegevoegd";
                }
            }
            return Message;



        }

        public string ACK(string bericht)
        {
            if (bericht.Equals("%Hello$"))
            {
                Message = "#Goodbye$";
            }
            else
            {
                Message = "What?";
            }
            return Message;

        }
    }
}
