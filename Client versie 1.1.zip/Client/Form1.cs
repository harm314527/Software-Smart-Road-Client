﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private string connection { get; set; }
        private void button1_Click(object sender, EventArgs e)
        {
            string serverIP = "localhost";
            string message = "%Hello$";
            MessageHandler.Connect(serverIP, message);
            string output = MessageHandler.output;
            if (output == "#Goodbye$")
            {
                connection = "Succes";
            }
            else
            {
                connection = "Fail";
            }
            state.Text = connection;
        }

        private void BtnAddToDatabase_Click(object sender, EventArgs e)
        {
            int nummer = Convert.ToInt32(RFID_Number.Value);
            int snelheid = Convert.ToInt32(RFID_Snelheid.Value);

            string message = "%Voeg RFID Toe:" + nummer + "," + snelheid + "$";
          
            string serverIP = "localhost";

            listBox1.Items.Add(MessageHandler.Connect(serverIP, message));
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string message = "%Lijst ophalen$";

            string serverIP = "localhost";

            MessageHandler.Connect(serverIP, message);
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }


    }
}
