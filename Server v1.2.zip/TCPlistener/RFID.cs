﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCPlistener
{
    class RFID
    {
        public  int Nummer { get; private set; }
        public int Snelheid { get; private set; }
        
        public RFID(int nummer, int snelheid)
        {
            this.Nummer = nummer;
            this.Snelheid = snelheid;
        }
        public static List<RFID> LoadAllFromDatabase()
        {
            // Voer een select-query uit om alle kunsten uit te lezen
            Database.Query = "SELECT * FROM RFIDS ORDER BY nummer";
            Database.OpenConnection();

            // De resultaten worden nu opgeslagen in een "reader": deze wordt in de while-loop
            // verderop gebruikt om nieuwe instanties van kunsten aan te maken
            SQLiteDataReader reader = Database.Command.ExecuteReader();

            // Onderstaande list bevat alle kunsten die uitgelezen worden
            List<RFID> RFID = new List<RFID>();
            while (reader.Read())
            {
                RFID.Add(new RFID(Convert.ToInt32(reader["nummer"]), Convert.ToInt32(reader["snelheid"])));
            }
            Database.CloseConnection();
            return RFID;
        }
        public static bool SaveToDatabase(int nummer, int snelheid)
        {
            // Bouw de insert-query op met de gegeven informatie

            Database.Query = "INSERT INTO RFIDS (nummer,snelheid) values (" + nummer
                + ", " + snelheid + ")";

            Database.OpenConnection();

            bool success = false;
            try
            {
                // ExecuteNonQuery wordt gebruikt als we geen gegevens verwachten van de query
                Database.Command.ExecuteNonQuery();
                success = true;
            }
            catch (SQLiteException e)
            {
                // Code 19 geeft aan dat een veld wat uniek moet zijn in de database, dit door
                // deze insert niet meer zou zijn. Het is dus niet toegevoegd. Aangezien in deze
                // applicatie deze constraint alleen op het Kunstnummer staat, kunnen we de
                // foutmelding heel specifiek weergeven.
                if (e.ErrorCode == 19)
                {
                    MessageBox.Show("'RFID nummer already exists.");
                }
            }

            Database.CloseConnection();
            return success;
        }
        public static bool ReplaceExistingdatabase(List<RFID> replacList )
        {
            Database.Query = "DELETE * FROM RFIDS";
            Database.OpenConnection();
            bool success = false;
 
            try
            {
                // ExecuteNonQuery wordt gebruikt als we geen gegevens verwachten van de query
                Database.Command.ExecuteNonQuery();
            }
            catch (SQLiteException ex)
            {
                return false;
            }
            foreach (RFID r in replacList)
            {
                Database.Query = "INSERT INTO RFIDS (nummer,snelheid) values ("+ r.Nummer
                                 + "', " + r.Snelheid + ")";

                Database.OpenConnection();

               
                try
                {
                    // ExecuteNonQuery wordt gebruikt als we geen gegevens verwachten van de query
                    Database.Command.ExecuteNonQuery();
                    success = true;
                }
                catch (SQLiteException e)
                {
                    // Code 19 geeft aan dat een veld wat uniek moet zijn in de database, dit door
                    // deze insert niet meer zou zijn. Het is dus niet toegevoegd. Aangezien in deze
                    // applicatie deze constraint alleen op het Kunstnummer staat, kunnen we de
                    // foutmelding heel specifiek weergeven.
                    if (e.ErrorCode == 19)
                    {
                        MessageBox.Show("'RFID nummer already exists.");
                    }
                }
            }
            Database.CloseConnection();
            return success;
        }
        public static bool DeleteSelectionFromDatabase(RFID RF)
        {
            bool success = false;
            // Voer een select-query uit om alle kunsten uit te lezen
            Database.Query = "SELECT * FROM RFIDS ORDER BY nummer";
            Database.OpenConnection();

            // De resultaten worden nu opgeslagen in een "reader": deze wordt in de while-loop
            // verderop gebruikt om nieuwe instanties van kunsten aan te maken
            SQLiteDataReader reader = Database.Command.ExecuteReader();

            // Onderstaande list bevat alle kunsten die uitgelezen worden
            List<RFID> listRFID = new List<RFID>();
            while (reader.Read())
            {
                listRFID.Add(new RFID(Convert.ToInt32(reader["nummer"]), Convert.ToInt32("snelheid")));
            }
            Database.CloseConnection();
            foreach (RFID rfid in listRFID )
            {
                if (rfid.Nummer == RF.Nummer)
                {
                    listRFID.Remove(rfid);
                }
            }
            foreach (RFID r in listRFID)
            {
                Database.Query = "INSERT INTO RFIDS (nummer,snelheid) values (" + r.Nummer
                                 + "', " + r.Snelheid + ")";

                Database.OpenConnection();


                try
                {
                    // ExecuteNonQuery wordt gebruikt als we geen gegevens verwachten van de query
                    Database.Command.ExecuteNonQuery();
                    success = true;
                }
                catch (SQLiteException e)
                {
                    // Code 19 geeft aan dat een veld wat uniek moet zijn in de database, dit door
                    // deze insert niet meer zou zijn. Het is dus niet toegevoegd. Aangezien in deze
                    // applicatie deze constraint alleen op het Kunstnummer staat, kunnen we de
                    // foutmelding heel specifiek weergeven.
                    if (e.ErrorCode == 19)
                    {
                        MessageBox.Show("'RFID nummer already exists.");
                    }
                }
            }
            Database.CloseConnection();
            return success;
        }
    }
}

