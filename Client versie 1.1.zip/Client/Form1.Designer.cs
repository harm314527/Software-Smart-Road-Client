﻿namespace Client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnConnect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.state = new System.Windows.Forms.Label();
            this.BtnAddToDatabase = new System.Windows.Forms.Button();
            this.RFID_Number = new System.Windows.Forms.NumericUpDown();
            this.RFID_Snelheid = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.BtnClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.RFID_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RFID_Snelheid)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnConnect
            // 
            this.BtnConnect.Location = new System.Drawing.Point(239, 32);
            this.BtnConnect.Name = "BtnConnect";
            this.BtnConnect.Size = new System.Drawing.Size(75, 23);
            this.BtnConnect.TabIndex = 0;
            this.BtnConnect.Text = "ACK";
            this.BtnConnect.UseVisualStyleBackColor = true;
            this.BtnConnect.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Connection: ";
            // 
            // state
            // 
            this.state.AutoSize = true;
            this.state.Location = new System.Drawing.Point(92, 42);
            this.state.Name = "state";
            this.state.Size = new System.Drawing.Size(0, 13);
            this.state.TabIndex = 2;
            // 
            // BtnAddToDatabase
            // 
            this.BtnAddToDatabase.Location = new System.Drawing.Point(239, 88);
            this.BtnAddToDatabase.Name = "BtnAddToDatabase";
            this.BtnAddToDatabase.Size = new System.Drawing.Size(148, 23);
            this.BtnAddToDatabase.TabIndex = 3;
            this.BtnAddToDatabase.Text = "Add RFID to database";
            this.BtnAddToDatabase.UseVisualStyleBackColor = true;
            this.BtnAddToDatabase.Click += new System.EventHandler(this.BtnAddToDatabase_Click);
            // 
            // RFID_Number
            // 
            this.RFID_Number.Location = new System.Drawing.Point(88, 70);
            this.RFID_Number.Name = "RFID_Number";
            this.RFID_Number.Size = new System.Drawing.Size(120, 20);
            this.RFID_Number.TabIndex = 4;
            // 
            // RFID_Snelheid
            // 
            this.RFID_Snelheid.Location = new System.Drawing.Point(88, 96);
            this.RFID_Snelheid.Name = "RFID_Snelheid";
            this.RFID_Snelheid.Size = new System.Drawing.Size(120, 20);
            this.RFID_Snelheid.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Nummer RFID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Snelheid RFID";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(239, 138);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Lijst uit database ophalen";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(95, 138);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(113, 21);
            this.comboBox1.TabIndex = 9;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 180);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(176, 173);
            this.listBox1.TabIndex = 10;
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(51, 363);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(75, 23);
            this.BtnClear.TabIndex = 11;
            this.BtnClear.Text = "CLear";
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 398);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RFID_Snelheid);
            this.Controls.Add(this.RFID_Number);
            this.Controls.Add(this.BtnAddToDatabase);
            this.Controls.Add(this.state);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnConnect);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.RFID_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RFID_Snelheid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnConnect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label state;
        private System.Windows.Forms.Button BtnAddToDatabase;
        private System.Windows.Forms.NumericUpDown RFID_Number;
        private System.Windows.Forms.NumericUpDown RFID_Snelheid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button BtnClear;
    }
}

