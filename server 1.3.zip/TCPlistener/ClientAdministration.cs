﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCPlistener
{
    class ClientAdministration
    {
        private SocketHelper helper = new SocketHelper();
        public TcpListener tcpListener = null;
          private List<string> adreszoneList = new List<string>();
        private List<TcpClient> clients = new List<TcpClient>();
        private IPAddress IpAddress { get;  set; }
        private int zone { get; set; }
        public void ConnectToClient()
        {
            IpAddress = IPAddress.Any;
            // Set the listener on the local IP address 
            // and specify the port.
            tcpListener = new TcpListener(IpAddress, 13);
            tcpListener.Start();
            //output = "Waiting for a connection...";
            // Create a TCP socket. 
            // If you ran this server on the desktop, you could use 
            // Socket socket = tcpListener.AcceptSocket() 
            // for greater flexibility.
            foreach (TcpClient tcp in clients)
            {
                
            }
            TcpClient tcpClient = tcpListener.AcceptTcpClient();
            if (tcpClient != null)
            {
                MessageBox.Show("verbonden");
            }
            byte[] bytes = new byte[256];
            NetworkStream stream = tcpClient.GetStream();
            stream.Read(bytes, 0, bytes.Length);
            helper.processMsg(tcpClient, stream, bytes);
            if (tcpClient.a)
            {
                
            }
            foreach (string s in adreszoneList)
            {
                if (s.StartsWith(Convert.ToString(IpAddress)))
                {
                    string[] spli = s.Split('=');
                    zone = Convert.ToInt32(spli[1]);

                }
                else
                {
                    zone++;
                    adreszoneList.Add(Convert.ToString(IpAddress)+"="+zone);
                }
            }
            tcpClient.Close();

        }
    }
}
