﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCPlistener
{
    class SocketHelper
    {
        TcpClient mscClient;
        string mstrMessage;
        string mstrResponse;
        byte[] bytesSent;

        public String LastMessage { get; private set; }

        public void processMsg(TcpClient client, NetworkStream stream, byte[] bytesReceived)
        {
            // Handle the message received and  
            // send a response back to the client.
            mstrMessage = Encoding.ASCII.GetString(bytesReceived, 0, bytesReceived.Length);
            mscClient = client;
            int count = 0;
            count = mstrMessage.IndexOf("$") + 1;
            mstrMessage = mstrMessage.Substring(0, count);
            handleMessage hen = new handleMessage(mstrMessage);
            hen.Compare(mstrMessage);
            LastMessage = mstrMessage;
            mstrResponse = hen.Message;
            bytesSent = Encoding.ASCII.GetBytes(mstrResponse);
            stream.Write(bytesSent, 0, bytesSent.Length);
        }

    }

}
